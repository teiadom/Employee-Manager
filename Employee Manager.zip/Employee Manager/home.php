<?php
include ('includes/header.php');
require_once ('mysql_connect.php');
?>
	
	<div style="width:100%; height:100%; margin-top:"> <img id="img" src="images/emp_home.png" alt="image" width="100%" height="80%"/></div><br/>
	<hr style ="color: blue;"/><br/>
			
	<!-- END Main -->
	<!-- Footer -->
	<?php
	include ('includes/footer.php');
	?>