<?php
// Start output buffering:
//ob_start();
session_start();
if (!isset($page_title)) {
	$page_title = 'EMPLOYEE MANAGER';
}
if (!isset($_SESSION['esname'])) {
	$url = 'index.php';
	header("Location: $url");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>OS CONCEPTS EMPLOYEE MANAGER</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!--<link rel="stylesheet" href="css/main.css" type="text/css" media="all" />-->
	 <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<!--<script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>-->
	<script type="text/javascript" src="js/zebra_datepicker.js"></script>
  <link rel="stylesheet" media="screen" type="text/css" href="css/zebra_datepicker.css" />
	<script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>
	<script src="js/jquery-func.js" type="text/javascript"></script>
	 <script type="text/javascript">
	 
	$(document).ready(function() {

		$('input.datepicker').Zebra_DatePicker();
	
	});
	</script>
	
	<style type = "text/css">
	
.container {
    width: 100%;
}

.image {
    width: 15%;
    max-width: 20%;
    display: block;
    float: left;
    margin-left: 10px;
}
.image2 {
    width: 15%;
    max-width: 20%;
    display: inline-block;
    float: right;
    margin-right: 10px;
}

.image img {
    width: 100%;
    height: auto;
}
.image2 img {
    width: 100%;
    height: auto;
}

.image:first-child {
    margin: 0;
}
.image2:first-child {
    margin: 0;
}

</style>
</head>
<body style="background-image:url('css/images/bg_image.jpg'); background-repeat: repeat-x; ">
<div class="header-bar clearfix">
	  
	 <img src="css/images/head2.png" style= "width:100%; height:140px;" alt="" class="logo">
	  
	  </div>

<div id="page" class="shell">
	<!-- Logo + Search + Navigation -->
	<div id="top">
		<div class="cl">&nbsp;</div>

	
		<div class="cl">&nbsp;</div>
		<div id="navigation">
			<ul>
			    
				   <li><a href="">SELF RECORD</a>
						<ul>
						<li><a href="addrec.php">Add Record</a></li>
						<li><a href="view_rec.php">Edit Record</a></li>
						</ul>
							</li>
				   <li><a href="">LEAVE</a>
						<ul>
						<li><a href="leave.php">Apply</a></li>
						<li><a href="leave_status.php">Status</a></li>
						</ul>
							</li>
					<ul>
						<li><a href="report.php">MARKETING REPORT</a></li>
						</ul>
			    	
			    </li>
				<?php
				if ($_SESSION['user_level'] == 2) {
					echo '
						<li><a href="">TRAINEE RECORD</a>
						<ul id="navigatn">
						<li><a href="add_train.php">Add Trainee</a></li>
						<li><a href="view_trainees.php">View Trainee</a></li>
						</ul>
							</li>
								<li><a href="view_report.php">VIEW REPORT</a></li>
					';}
				else if ($_SESSION['user_level']==3){
				echo '
						<li><a href="">TRAINEE RECORD</a>
						<ul id="navigatn">
						<li><a href="add_train.php">Add Trainee</a></li>
						<li><a href="view_trainees.php">View Trainee</a></li>
						</ul>
							</li>
						<li><a href="view_report.php">VIEW REPORT</a></li>
						<li><a href="approval.php">APPROVAL</a></li>
														
					';}			
					?>
				
				<li>
			    	<a style="font-size:10px;" href="logout.php"><span>Logout</span></a>
			    	
			    </li> 
				
			  
			</ul>
		</div>	
	</div>
	<!-- END Logo + Search + Navigation -->
	
	<!-- Main -->
	<div id="main">