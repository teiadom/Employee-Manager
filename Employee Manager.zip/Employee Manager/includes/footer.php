
<div id="footer">
	<div align="center">
		<p class="right" style="font-size:13px; font-color: orange; font-weight: bold;">&copy; 2016 - OS CONCEPTS EMPLOYEE MANAGER &nbsp; </p>
		</div>
		
	</div>
	<!-- END Footer -->
	<br />
</div>
</body>
</html>
<?php // Flush the buffered output.
ob_end_flush();
?>


